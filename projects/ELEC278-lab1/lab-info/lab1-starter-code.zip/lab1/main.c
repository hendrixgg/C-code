#include <stdio.h>

int array_average(const int *array, size_t count) {
    // TODO: return the average of the 'count' elements of 'array'.
    return 0;
}

int main() {
    // TODO: construct an array, call 'array_average' on it, and print the result.
    printf("Hello, World!\n");
    return 0;
}
