#include <malloc.h>
#include "stack.h"

struct stack_node {
    // TODO (task 1): what fields do we need here?
};

struct stack {
    // Null if the stack is empty.
    struct stack_node *head;
};

stack_ptr stack_new() {
    stack_ptr s = malloc(sizeof(struct stack));
    s->head = NULL;
    return s;
}

void stack_free(stack_ptr s) {
    // TODO (task 1): how do we make sure the nodes don't leak memory?
    free(s);
}

void stack_push(stack_ptr s, char c) {
    // TODO (task 1): how do we push an entry onto the stack?
}

bool stack_pop(stack_ptr s, char *out) {
    // TODO (task 1): how do we pop an entry from the stack?
    return false;
}
