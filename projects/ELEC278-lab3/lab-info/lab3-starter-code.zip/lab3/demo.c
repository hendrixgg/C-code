#include "demo.h"
#include "stack.h"

bool check_brackets(const char *str) {
    stack_ptr s = stack_new();

    // TODO (task 3): using the stack 's', check the brackets in the strings.

    stack_free(s);
    return true;
}
