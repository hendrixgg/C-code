#include "queue.h"

void init_queue(struct queue *q) {
    q->data = NULL;
    q->capacity = 0;
    q->offset = 0;
    q->length = 0;
}

void clear_queue(struct queue *q) {
    if (q->data != NULL) {
        free(q->data);
        init_queue(q);
    }
}

void enqueue(struct queue *q, int value) {
    // TODO: Task 1: add an element to the circular queue.
}

bool dequeue(struct queue *q, int *out) {
    // TODO: Task 1: remove an element from the circular queue.
    return false;
}

bool queue_empty(struct queue *q) {
    // TODO: Task 1: check whether the queue is empty.
    return false;
}
