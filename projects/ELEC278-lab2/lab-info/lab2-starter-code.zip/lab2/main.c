#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

// Null for an empty list.
typedef struct list_node *list;

struct list_node {
    int value;
    list tail;
};

typedef list *iterator;

// Inserts a number at a given position in a list.
void insert_at(iterator iter, int num) {
    // Construct a new node to splice into the list.
    struct list_node *new_node = malloc(sizeof(struct list_node));
    new_node->value = num;

    // 'iter' points to the 'tail' slot where we need to insert the node.
    new_node->tail = *iter;
    *iter = new_node;
}

// Inserts a number at a given position in a list.
// Returns false if the iterator is at the end of the list.
bool remove_at(iterator iter) {
    // Make sure we are not at the end.
    if (*iter == NULL)
        return false;

    // 'iter' points to the 'tail' slot where we need to remove the node.
    struct list_node *old_node = *iter;
    *iter = old_node->tail;
    free(old_node);
    return true;
}

// Checks whether the iterator is at the end of the list.
bool at_end(iterator iter) {
    return *iter == NULL;
}

// Gets the value at an iterator.
// Only valid if !at_end(iter).
int get(iterator iter) {
    return (*iter)->value;
}

// Advances an iterator to the next position.
// Returns false if the iterator is at the end of the list.
bool next(iterator *iter) {
    if (at_end(*iter))
        return false;

    *iter = &(**iter)->tail;
    return true;
}

// Prints the contents of the list.
void print_list(list nums) {
    // TODO: implement this (task 1).
    printf("\n");
}

// Swaps adjacent items in the list.
void swap_adjacent(list *nums) {
    // TODO: implement this (task 2).
}

// Duplicates all items in the list end to end.
void double_list(list *nums) {
    // TODO: implement this (task 3).
}

// Removes adjacent duplicate items in the list.
void remove_adjacent_duplicates(list *nums) {
    // TODO: implement this (task 2).
}

int main() {
    // List is initially empty.
    list numbers = NULL;

    // TODO: construct the list (task 1).

    printf("Original list: ");
    print_list(numbers);

    printf("Swapping adjacent items: ");
    swap_adjacent(&numbers);
    print_list(numbers);

    printf("Duplicating all items: ");
    double_list(&numbers);
    print_list(numbers);

    printf("Removing adjacent duplicates: ");
    remove_adjacent_duplicates(&numbers);
    print_list(numbers);

    return 0;
}
