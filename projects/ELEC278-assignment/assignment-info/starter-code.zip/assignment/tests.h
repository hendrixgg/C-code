#ifndef ASSIGNMENT_TESTS_H
#define ASSIGNMENT_TESTS_H

void run_tests();

#endif //ASSIGNMENT_TESTS_H
